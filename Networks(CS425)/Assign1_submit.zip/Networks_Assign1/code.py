import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
# 2.0 -45 -42 -41 -42 -42.5
# 3.9 -46 -50 -46 -48 -47.5
# 6.5 -51 -54 -52 -51 -52
# 7.5 -57 -54 -54 -57 -55.5
# 9.5 -59 -57 -57 -58 -57.75
# 11.1 -62 -61 -62 -60 -61.25
# 14.9 -61 -63 -62 -62 -62
# 16.9 -62 -62 -64 -62 -62.5
# Define the data: distances in meters and corresponding RSSI values in dBm
distances = np.array([1.9,3.1, 4.0, 6.1, 8.3, 10.4,12.1])  # Example distances
rssis= np.array([[-28, -30, -29, -27],
                  [-33, -31, -33, -32],
                  [-36, -37, -36, -38],
                  [-39, -38, -41, -40],
                  [-45, -46, -44, -43],
                  [-43, -43, -45, -44],
                  [-48, -46, -49, -47]])
rssi_samples =  np.mean(rssis, axis=1)  # Example RSSI values
print(rssi_samples)
# Convert distances to log scale
log_distances = np.log10(distances)

# Plot the log-log graph
plt.scatter(log_distances, rssi_samples, label='RSSI Data', color='blue')
plt.xlabel('Log Distance (log10)')
plt.ylabel('RSSI (dBm)')

# Perform linear regression to find the best fit line
X = log_distances.reshape(-1, 1)
y = rssi_samples
model = LinearRegression()
model.fit(X, y)
for i in range(len(distances)):
    plt.scatter([log_distances[i]] * len(rssis[i]), rssis[i], color='green', alpha=0.5)

# Plot the best fit line
plt.plot(log_distances, model.predict(X), color='red', label='Best Fit Line')

# Find path loss exponent
path_loss_exponent = abs(model.coef_[0] / 10)
print(f'Path Loss Exponent: {path_loss_exponent}')

# Find variance of RSSI samples w.r.t. the best fit line
variance = np.var(y - model.predict(X))
print(f'Variance of RSSI samples: {variance}')

slope = model.coef_[0]
intercept = model.intercept_
equation = f'RSSI = {slope:.2f} * x + {intercept:.2f}'
print(f'Equation of the line: {equation}')

sum=0.0
for i in range(len(rssi_samples)):
    print(f'Predicted dis and err: {(10**((-model.intercept_+rssi_samples[i])/model.coef_[0])),10**((-model.intercept_+rssi_samples[i])/model.coef_[0])-distances[i]}')
    sum+=abs((10**((-model.intercept_+rssi_samples[i])/model.coef_[0]))-distances[i])
print(f'ERR:Part2: {sum/len(rssi_samples)}')
# Show the plot
plt.legend()
plt.show()
