#include <bits/stdc++.h>
using namespace std;

string random_string(int k)
{
    string s = "";
    while (k--)
    {
        s += ((rand() % 2) ? '1' : '0');
    }
    return s;
}
string xorOfStrings(string a, string b)
{
    string result = "";
    for (int i = 0; i < min(a.size(), b.size()); i++)
    {
        result += (a[i] == b[i]) ? '0' : '1';
    }
    return result;
}

string generate_t(string message, string crc)
{
    string remainder = "";
        message = message + string(crc.size() - 1, '0');
    string curr = message.substr(0, crc.size());
    for (int i = 0; i < message.size() - crc.size(); i++)
    {
        if (curr[0] == '1')
        {
            curr = xorOfStrings(curr, crc);
        }
        curr = curr.substr(1) + message[i + crc.size()];
        // cout << curr << "\n";
    }
    if (curr[0] == '1')
    {
        curr = xorOfStrings(curr, crc);
    }
    curr = curr.substr(1);
    return message.substr(0, message.size() - crc.size() + 1) + curr;
}
string generate_error(string t)
{

    for (int i = 0; i < t.size(); i++)
    {
        if (rand() % 9== 0)
        {
            t[i] = '1' - t[i] + '0';
        }
    }
    return t;
}
int whetherToAccept(string message, string crc)
{
    string curr = message.substr(0, crc.size());
    for (int i = 0; i < message.size() - crc.size(); i++)
    {
        if (curr[0] == '1')
        {
            curr = xorOfStrings(curr, crc);
        }
        curr = curr.substr(1) + message[i + crc.size()];
        // cout << curr << "\n";
    }
    if (curr[0] == '1')
    {
        curr = xorOfStrings(curr, crc);
    }
    curr = curr.substr(1);
    return (curr == string(crc.size() - 1, '0'));
}
int ques1(int flag)
{
    string message, crc;
    int n = 16, k = 10;
    if (flag == 0)
    {
        cout << "Do you want to generate random message of K=10 bits. Write YES or NO \n";
        cin >> message;
        if (message == "YES")
        {
            message = random_string(10);
        }
        else if (message == "NO")
        {
            cout << "Tell K-bit data block size\n";
            cin >> k;
            cout << "Do you want to generate random message of K=" << k << " bits. Write YES or NO \n";
            cin >> message;
            if (message == "YES")
            {
                message = random_string(k);
            }
            else if (message == "NO")
            {
                cout << "Write your own message of K=" << k << " bits\n";
                cin >> message;
                if (message.size() != k)
                {
                    cout << "ERROR: Message size should be equal to K\n";
                    exit(0);
                }
            }
            else
            {
                cout << "ERROR: Please write YES or NO\n";
                exit(0);
            }
        }
        else
        {
            cout << "ERROR: Please write YES or NO\n";
            exit(0);
        }
        string input;
        cout << "Do you want to run part2 P=110101 and n=15. Write YES or NO\n";
        cin >> input;
        if (input == "YES")
        {
            crc = "110101";
            n = 15;
        }
        else if (input != "NO")
        {
            cout << "ERROR: Please write YES or NO\n";
            exit(0);
        }
        else
        {
            cout << "Tell N-bit frame size for transmission greater than equal k=" << k << "\n";
            cin >> n;
            if (n < k)
            {
                cout << "ERROR: N should be greater than K\n";
                exit(0);
            }

            cout << "Do you want to generate random polynomial of N-K+1 bits. Write YES or NO\n";
            cin >> crc;
            if (crc == "YES")
            {
                crc = random_string(n - k + 1);
                crc[rand() % crc.size()] = '1';
            }
            else
            {
                cout << "Write your own polynomial of CRC(P) N-K+1 bits\n";
                cin >> crc;
                if (crc.size() != n - k + 1)
                {
                    cout << "ERROR: Polynomial size should be equal to N-K+1\n";
                    exit(0);
                }
            }
        }
    }
    else
    {
        n = rand() % 20+5;
        k = rand() % n + 1;
        message = random_string(k);
        crc = random_string(n - k + 1);
    }
    cout << "N=" << n << ", K=" << k << ", message=" << message << ", crc(P)=" << crc << "\n";
    string t = generate_t(message, crc);
    cout << "Transmission Frame is:" << t << "\n";
    string error = generate_error(t);
    cout << "Part3 : String after generating trasmission errors is:" << error<< "\n";
    if (whetherToAccept(error, crc))
    {
        cout << "Part4 : The frame can be accepted\n";
    }
    else
    {
        cout << "Part4 : The frame should be discarded\n";
    }
    return 0;
}

int main()
{
    string input;
    cout << "Do you want to run question 1 on random tcs, Write YES or NO\n";
    cin >> input;
    if (input == "YES")
    {
        for (int i = 0; i < 5; i++)
        {
            ques1(1);
            cout << "\n";
        }
    }
    else if (input == "NO")
    {
        ques1(0);
    }
    else
    {
        cout << "ERROR: Please write YES or NO\n";
        exit(0);
    }

    // wcout<<whetherToAccept("000110110111100","10011");
    //    wcout<<whetherToAccept("000010110111100","10011");
}