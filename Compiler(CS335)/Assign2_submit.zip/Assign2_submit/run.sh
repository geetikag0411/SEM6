flex lexer.l
bison -d parser.y
g++ lex.yy.c parser.tab.c parser.tab.h -o parser
./parser