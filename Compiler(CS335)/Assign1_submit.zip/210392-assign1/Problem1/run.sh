flex sol.l;
g++ lex.yy.c -ll;
if [[ $# != 1 ]] && [[ $# != 2 ]];
then
    echo "Script should be used with either 1 or 2 arguments (of type file name)"
    echo "Error in using the script..."
    exit 1
fi
if [ $# -eq 2 ]; 
then
    ./a.out $1 > $2
else
    ./a.out $1 
fi